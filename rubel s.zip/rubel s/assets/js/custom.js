(function($){
    
$('.demo').percentcircle({

    animate: true,
    diameter: 100,
    guage: 2,
    coverBg: '#fff',
    bgColor: '#efefef',
    fillColor: '#5c93c8',
    percentSize: '15px',
    percentWeight: 'normal',

	});
    
	
}(jQuery));